function register() {
    if (validate()) {
        alert("Thank you for your registration!");
    }
}

function validate() {
    var success;
    var mail = document.getElementById("mail").value;
    // TODO 1: validate email address
    //         -> [>0 chars] @ [>0 two chars] . [>0 chars]
    //         -> Hint 1: Regular Expression: "^[^@]+@[^@\.,;]+\.[^@\.,;]+$"
    var regex = RegExp("^[^@]+@[^@\.,;]+\.[^@\.,;]+$");
    success = regex.test(mail);
    // TODO 2: show an error message if not valid
    //         -> create a node of class "error" with id "error"
    //            and append it to the div with id "maildiv"
    //         -> Hint 1: the document object helps you a lot!
    //         -> Hint 2: don't append, if already present!

    if(!success){
        var child = document.createElement("div");
        var currentDiv = document.getElementById("maildiv");
        currentDiv.appendChild(child);
        child.setAttribute("class", "error");
        child.innerHTML = "E-Mailadresse falsch";
    }
    return success;
}