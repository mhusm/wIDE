function get_todos() {
    var todos = new Array;
    var todos_str = localStorage.getItem('todo');
    if (todos_str !== null) {
        todos = JSON.parse(todos_str);
    }
    return todos;
}

function add() {
    var task = document.getElementById('task').value;
    var taskEntry = {};
    taskEntry.task = document.getElementById('task').value;
    taskEntry.category = document.getElementById('category').options[document.getElementById('category').selectedIndex].value;
    taskEntry.status = '';

    var todos = get_todos();
    todos.push(taskEntry);
    localStorage.setItem('todo', JSON.stringify(todos));

    show();

    return false;
}

function remove() {
    var id = this.getAttribute('id');
    var todos = get_todos();
    todos.splice(id, 1);
    localStorage.setItem('todo', JSON.stringify(todos));

    show();

    return false;
}

function check() {
    var id = this.getAttribute('id');
    var todos = get_todos();
    todos[id].status = 'done';
    localStorage.setItem('todo', JSON.stringify(todos));

    show();

    return false;
}

function uncheck() {
    var id = this.getAttribute('id');
        var todos = get_todos();
        todos[id].status = '';
        localStorage.setItem('todo', JSON.stringify(todos));

        show();

        return false;
}

function show() {
    console.log('hello');
    var todos = get_todos();

    var ul = document.createElement("ul");
    for(var i=0; i<todos.length; i++) {
        var li = document.createElement("li");
        li.setAttribute("id", "list_" + i);
        li.className = "todo";
        li.className = li.className + ' ' + todos[i].category;
        li.innerHTML = todos[i].task;

        var removeButton = document.createElement("button");
        removeButton.setAttribute("id", i);
        removeButton.setAttribute("class", "remove");
        removeButton.innerHTML = "x";

        var checkButton = document.createElement("button");
        checkButton.setAttribute("id", "check_"+i);

        if (todos[i].status === "done") {
            li.className = li.className + ' done';
            checkButton.innerHTML = '&#x21bb;';
            checkButton.setAttribute("class", "uncheck");
        } else {
            checkButton.innerHTML = '&#10004;';
            checkButton.setAttribute("class", "check");
        }

        li.appendChild(checkButton);
        li.appendChild(removeButton);
        ul.appendChild(li);
    };

    var todos = document.getElementById('todos');
    while(todos.hasChildNodes()) {
        todos.removeChild(document.getElementById('todos').lastChild);
    }
    todos.appendChild(ul);

    var ul = todos.childNodes[0];
    for (var i=0; i < ul.length; i++) {
        var li = ul.childNodes[i];
    }
    var checkButtons = document.getele;
    for (var i=0; i < checkButtons.length; i++) {
        checkButtons[i].addEventListener('click', check);
    };
    var checkButtons = document.getElementsByClassName('uncheck');
    for (var i=0; i < checkButtons.length; i++) {
        checkButtons[i].addEventListener('click', uncheck);
    };

    var buttons = document.getElementsByClassName('remove');
    for (var i=0; i < buttons.length; i++) {
        buttons[i].addEventListener('click', remove);
    };
}

var addButton = document.getElementById('add');
addButton.addEventListener('click', add);
show();